/*
 * This is a sample JavaScript file used by {{ name }}
 *
 * You can delete this file if you want
 */
